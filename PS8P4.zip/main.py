def compprice(miles):
  if float(miles) >= 30 :
    price = 12
  elif float(miles) >= 20:
    price = 10
  elif float(miles) >= 10:
    price = 8 
  else:
    price = 5 
  
  return price 

totprice = 0

response = input("Do you want to compute ticket price?(Yes or No): ")

while response == "Yes":
  name = input("Enter Lastname: ")
  miles = input("Enter miles from downtown Chicago: ")
  
  price = compprice(miles)

  totprice = totprice + price

  print(name , ", price of ticket is $" , price)

  response = input("Do you want to compute ticket price?(Yes or No)")

print("Sum of all tickets is $", totprice)


