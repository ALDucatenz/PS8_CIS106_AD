def compvalue(county,market):
  if county == "Cook":
    assessed = .9 * float(market)
  elif county == "Dupage":
    assessed = .8 * float(market)
  elif county == "McHenry":
    assessed = .75 * float(market)
  elif county == "Kane":
    assessed = .6 * float(market)
  else:
    assessed = .7 * float(market)
  
  return assessed

response = input("Do you want to compute assessed value? (Yes or No): ")

while response == "Yes":
  county = input("Enter County: ")
  market = input("Enter Market value: $")

  assessed = compvalue(county,market)

  print("Assessed value of home is $", assessed)

  response = input("Do you want to compute assessed value? (Yes or No): ")
