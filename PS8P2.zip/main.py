def compsquare(length,width,height) :
  square = (2 * float(length) * float(width)) + (2 * float(length) * float(height)) + (2 * float(width) * float(height))

  return square

def compgal(square) :
  gal = float(square) / 50

  return gal 

response = input("Do you want to compute the number of gallons of paint needed? (Yes or No): ")

while response == "Yes" :
  length = input("Enter length of room: ")
  width = input("Enter width of room: ")
  height = input("Enter height of room: ")

  square = compsquare(length,width,height)

  gal = compgal(square)

  print("Gallons of painted needed to cover the entire room: " , gal)
  
  response = input("Do you want to compute the number of gallons of paint needed? (Yes or No): ")





