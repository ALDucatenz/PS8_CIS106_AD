def compforecast(month,sales) :
  if month == "Jan" or month =="Feb" or month == "Mar" :
    forecast = float(sales) * 1.1
  elif month == "Apr" or month =="May" or month == "Jun" :
    forecast = float(sales) * 1.15
  elif month == "July" or month =="Aug" or month == "Sep" :
    forecast = float(sales) * 1.2
  elif month == "Oct" or month =="Nov" or month == "Dec" :
    forecast = float(sales) * 1.25
  else:
    forecast = 0
  
  return forecast

response = input("Do you want to compute next month's forecast?(Yes or No): ")

while response == "Yes":
  name = input("Enter Lastname: ")
  month = input("Enter Month: ")
  sales = input("Enter sales: $")
 
  forecast = compforecast(month,sales)
  
  print(name , ", Next month's sales are projected to be $" , forecast)

  response = input("Do you want to compute next month's forecast?(Yes or No): ")
