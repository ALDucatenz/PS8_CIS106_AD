def comptotal(make,model,electric,MSRP):
  if make == "Honda" and model == "Accord":
    total = float(MSRP) - (float(MSRP) * .1) + (float(MSRP) * .07)
  elif make == "Toyota" and model == "Rav4":
    total = float(MSRP) - (float(MSRP) * .15) + (float(MSRP) * .07)
  elif electric == "Y":
    total = float(MSRP) - (float(MSRP) * .3) + (float(MSRP) * .07)
  else:
    total = float(MSRP) - (float(MSRP) * .05) + (float(MSRP) * .07)
  
  return total

totmsrp = 0 
sumtot = 0

response = input("Do you want to compute sales price of cars (Yes or No): ")

while response == "Yes":
  make = input("Enter make of car: ")
  model = input("Enter model of car: ")
  electric = input("Is vehicle electric? (Y or N): ")
  MSRP = input("Enter MSRP: ")
  
  totmsrp = totmsrp + float(MSRP)
  
  total = comptotal(make,model,electric,MSRP)

  sumtot = total + sumtot

  print("Car's sales price is $", total)

  response = input("Do you want to compute sales price of cars (Yes or No): ")

print("Sum of all MSRP is $", totmsrp)

print("Sum of all sales price of cars is $", sumtot)





